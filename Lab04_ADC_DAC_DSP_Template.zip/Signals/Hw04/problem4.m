Impulse_func = Impulse(); %Impulse Function Array of Data
Unit_func = Unit(); %Unit-Step Function Array of Data
y_step = conv(Impulse_func, Unit_func); %Convolve u[n] with h[n]
Normalize_factor = max(y_step); %Find highest value in array
%Normalize so the highest element in array is 1
y_step_normalized = rdivide(y_step, Normalize_factor); 
stem(Impulse_func);
axis([0 100 -0.2 1]);
hold;
stem(y_step_normalized);
axis([0 100 -0.2 1.2]);